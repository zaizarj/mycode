# python-datasci-classifying-natural-writing
Machine Learning source material and code
